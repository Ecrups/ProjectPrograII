# Sistema POS para supermercado — Programación II

Proyecto Java 21 con Swing, JDBC y Oracle XE 21c

## Estado del proyecto
**Implementación.** Se incluyen las 12 pantallas previstas, modelo de dominio, DAOs básicos, operaciones transaccionales, SQL, permisos y contraseñas PBKDF2. Compila con JDK 21.

## Preparación
1. Instalar JDK 21 y Oracle XE 21c; crear usuario POS ejecutando `sql/00_usuario.sql` como SYSTEM.
2. Conectarse como POS a XEPDB1; ejecutar `sql/01_esquema.sql` y después `sql/02_datos_iniciales.sql`.
3. Descargar de Oracle el controlador oficial `ojdbc11.jar` y colocarlo en `lib/`. **No se incluye por licencia/descarga externa.**
4. Crear hash de administrador mediante `java ... GenerarHash Admin123!` después de compilar;
5. Compilar/ejecutar desde la carpeta `pos` con `compilar_windows.bat` y `ejecutar_windows.bat` o abrir `src` en VS Code, NetBeans, Eclipse o IntelliJ y configurar Java 21 + JDBC.

## Estructura
- `src/com/supermercado/pos/dominio`: POJO y enums.
- `dao`: acceso JDBC mediante PreparedStatement y DAOs.
- `servicio`: autenticación, reglas de negocio y transacciones.
- `ui`: pantallas Swing y diálogos.
- `util`: conexión, sesión y seguridad.
- `excepcion`: excepciones de negocio.
- `sql`: esquema y datos de ejemplo.


## Aviso
El proyecto contiene implementación adicional realizada a partir de los requerimientos solicitado por el usuario.